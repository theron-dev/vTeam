/**
 *  ___VARIABLE_classPrefix___Shell.h
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
 */


#import <UIKit/UIKit.h>
#import <vTeam/vTeam.h>
#import "___VARIABLE_classPrefix___Context.h"

@interface ___VARIABLE_classPrefix___Shell : VTShell<UIApplicationDelegate> {
}

@property (strong, nonatomic) IBOutlet UIWindow *window;

@end
