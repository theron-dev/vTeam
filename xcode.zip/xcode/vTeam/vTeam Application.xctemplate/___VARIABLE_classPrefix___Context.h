/**
 *  ___VARIABLE_classPrefix___Context.h
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
 */

#import <Foundation/Foundation.h>

@protocol ___VARIABLE_classPrefix___Context <NSObject>

@end
