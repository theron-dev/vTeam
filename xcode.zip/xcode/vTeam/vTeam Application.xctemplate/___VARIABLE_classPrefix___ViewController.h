/**
 *  ___VARIABLE_classPrefix___ViewController.h
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
 */

#import <vTeam/vTeam.h>

@interface ___VARIABLE_classPrefix___ViewController : VTViewController

@end
